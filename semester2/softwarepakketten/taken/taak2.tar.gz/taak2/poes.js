function ogenToe() {
    document.getElementById("cat").src = "ogentoe.jpg";
};
function ogenOpen() {
    document.getElementById("cat").src = "ogenopen.jpg";
};
